from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import glob
import concurrent.futures

import math
import os
from os import listdir, path

import tensorflow as tf

import numpy as np
import matplotlib.pyplot as plt
from IPython import display

import PIL.Image
import PIL.ImageOps
import PIL.ImageFont
import PIL.ImageDraw
import textwrap
from io import BytesIO
from tqdm import tqdm
import imghdr

#from im2txt.configuration import configuration
import sys
im2txt_path = 'D:/SE2023-9.1/SDmodel/imageCaptioning/im2txt/'
inference_utils_path = 'D:/SE2023-9.1/SDmodel/imageCaptioning/im2txt/inference_utils/'
ops_path = 'D:/SE2023-9.1/SDmodel/imageCaptioning/im2txt/ops/'
sys.path.append(im2txt_path)
sys.path.append(inference_utils_path)
sys.path.append(ops_path)
import im2txt
import configuration
import inference_wrapper
import caption_generator
import vocabulary

# Choose the trained model --> current is 2
model_number = "2"
model_path = "D:/SE2023-9.1/SDmodel/image_captioning_model/model.ckpt-"+model_number+"000000"   # Give model path
vocab_path = "D:/SE2023-9.1/SDmodel/image_captioning_model/word_counts"+model_number+".txt"     # Give word_counts file path
tf.logging.set_verbosity(tf.logging.INFO)

# Build the inference graph.
g = tf.Graph()
with g.as_default():
    model = inference_wrapper.InferenceWrapper()
    restore_fn = model.build_graph_from_config(configuration.ModelConfig(), model_path)
g.finalize()

# Create the vocabulary.
vocab = vocabulary.Vocabulary(vocab_path) 

#######################################################
### if tensorflow version is <1.13.2 then you have to check variables name as per tensorflow version

'''
OLD_CHECKPOINT_FILE = "D:/SE2023-9.1/SDmodel/image_captioning_model/model.ckpt-2000000"
NEW_CHECKPOINT_FILE = "D:/SE2023-9.1/SDmodel/image_captioning_model/model.ckpt-2000000"

vars_to_rename = {
    "lstm/BasicLSTMCell/Linear/Matrix": "lstm/basic_lstm_cell/kernel",
    "lstm/BasicLSTMCell/Linear/Bias": "lstm/basic_lstm_cell/bias",
}
new_checkpoint_vars = {}
reader = tf.train.NewCheckpointReader(OLD_CHECKPOINT_FILE)
for old_name in reader.get_variable_to_shape_map():
  if old_name in vars_to_rename:
    new_name = vars_to_rename[old_name]
  else:
    new_name = old_name
  new_checkpoint_vars[new_name] = tf.Variable(reader.get_tensor(old_name))

init = tf.global_variables_initializer()
saver = tf.train.Saver(new_checkpoint_vars)

with tf.Session() as sess:
  sess.run(init)
  saver.save(sess, NEW_CHECKPOINT_FILE)

#######################################################
'''
sess = tf.Session(graph=g)
# Load the model from checkpoint.
restore_fn(sess)

# Prepare the caption generator. Here we are implicitly using the default
# beam search parameters. See caption_generator.py for a description of the
# available beam search parameters.
generator = caption_generator.CaptionGenerator(model, vocab)


image_path = "D:/SE2023-9.1/SDmodel/data/train"    #### provide path where image is stored

dirnames = glob.glob(image_path+'/*')
#print(filenames)

#ogfile = glob.glob(image_path+'*/*')
for i,dir in tqdm(enumerate(dirnames)):
  file_list = glob.glob(dir+'/*')
  for j, file in tqdm(enumerate(file_list)):
    new_path = os.path.join(os.path.dirname(file), f'Image_{i}_{j}.jpg')   
    # Check if the target file already exists
    if not os.path.exists(file):
      continue
    if os.path.exists(new_path):
      continue  # Skip the renaming if the file already exists
    # Rename the file
    os.rename(file, new_path)

nimgs = glob.glob(image_path+'/*/*')
for img in tqdm(nimgs):
  try:
    img_format = imghdr.what(img)
    format_list = ['png', 'jpg', 'jpeg', 'PNG', 'JPG', 'JPEG']
    
    if img_format not in format_list:
      os.remove(img)
    
    image = PIL.Image.open(img).convert('RGBA')
    image.close()
  except (PIL.UnidentifiedImageError, OSError):
    if os.path.exists(img):
      os.remove(img)
    continue

'''
imgs = glob.glob(image_path+'/*/*')
store = open('D:/SE2023-9.1/SDmodel/data/train/logs-train.txt','w')   #### directory to store captions file
for file in imgs:
  try:
    img = PIL.Image.open(file).convert('RGBA')
    box = PIL.Image.new('RGBA', img.size, (255,255,255,0))
    draw = PIL.ImageDraw.Draw(box)
    image = open(file, 'rb').read()  # Read the image as bytes
    captions = generator.beam_search(sess, image)
    for i, caption in enumerate(captions):
      # Ignore begin and end words.
      sentence = [vocab.id_to_word(w) for w in caption.sentence[1:-1]]
      sentence = " ".join(sentence)
      if i==0:
        print(file + " : %s " % (sentence))
        # create log file image_name--image_caption
        store.write(file + "," + sentence + "\n")
  except PIL.UnidentifiedImageError:
    os.remove(file)
    continue
store.close()
'''

def process_image(file):
  try:
    img = PIL.Image.open(file).convert('RGBA')
    box = PIL.Image.new('RGBA', img.size, (255, 255, 255, 0))
    draw = PIL.ImageDraw.Draw(box)
    image_bytes = open(file, 'rb').read()

    captions = generator.beam_search(sess, image_bytes)
    for i, caption in enumerate(captions):
      sentence = [vocab.id_to_word(w) for w in caption.sentence[1:-1]]
      sentence = " ".join(sentence)
      if i == 0:
        #print(file + ": %s" % sentence)
        with open('D:/SE2023-9.1/SDmodel/data/train/logs-train.txt', 'a') as store:
          store.write(file + "," + sentence + "\n")
  except (PIL.UnidentifiedImageError, IOError):
    os.remove(file)

image_path = "D:/SE2023-9.1/SDmodel/data/train/"

imgs = glob.glob(image_path + '/*/*')

with concurrent.futures.ThreadPoolExecutor() as executor:
    list(tqdm(executor.map(process_image, imgs), total=len(imgs)))