import glob
from tqdm import tqdm
image_path = "D:/SE2023-9.1/SDmodel/data/train"    #### provide path where image is stored

dirnames = glob.glob(image_path+'/*')
print(dirnames)

#ogfile = glob.glob(image_path+'*/*')
for i,dir in tqdm(enumerate(dirnames)):
    file_list = glob.glob(dir+'/*')
    #print(file_list)
