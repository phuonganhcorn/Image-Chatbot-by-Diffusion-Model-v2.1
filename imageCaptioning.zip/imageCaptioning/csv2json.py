import csv 
import json
import time

def text_to_csv(textFilePath, csvFilePath):
    # Read the text file
    with open(textFilePath, 'r', encoding='utf-8') as textFile:
        lines = textFile.readlines()

    # Write the text file content to the CSV file
    with open(csvFilePath, 'w', encoding='utf-8', newline='') as csvFile:
        writer = csv.writer(csvFile)
        writer.writerow(['link', 'caption'])  # Write header row
        for line in lines:
            # Split the line into link and caption
            link, caption = line.strip().split(',', 1)
            caption = caption.rstrip('.')
            writer.writerow([link, caption])
    print(f"Conversion {len(lines)} rows completed successfully.")


def csv_to_json(csvFilePath, jsonFilePath):
    jsonArray = []
      
    #read csv file
    with open(csvFilePath, encoding='utf-8') as csvf: 
        #load csv file data using csv library's dictionary reader
        csvReader = csv.DictReader(csvf) 

        #convert each csv row into python dict
        count = 0
        for row in csvReader: 
            #add this python dict to json array
            jsonArray.append(row)
            count += 1
  
    #convert python jsonArray to JSON String and write to file
    with open(jsonFilePath, 'w', encoding='utf-8') as jsonf: 
        jsonString = json.dumps(jsonArray, indent=4)
        jsonf.write(jsonString)
    
    if count != -1:
        print(f"Conversion of {count} lines completed successfully.")
            
    

if __name__ == '__main__':
    textFilePath = 'D:/SE2023-9.1/SDmodel/data/train/logs-train.txt'
    csvFilePath = 'D:/SE2023-9.1/SDmodel/data/train/logs-train.csv'
    jsonFilePath = 'D:/SE2023-9.1/SDmodel/data/train/logs-train.json'

    text_to_csv(textFilePath, csvFilePath)
    csv_to_json(csvFilePath, jsonFilePath)

    