# noqa: C801
__version__ = "0.0.23+97cc81f.d20231122"
